import numpy as np
from scipy.optimize import minimize
from KS_solver import KS_step, ml_step

"""
Loss function to train the ML model
The L2 error of the model against the ground truth averaged across
the different rollout periods
Inputs:
   params - the parameters for the solver matrix which will be optimized
   data - the ground truth data at all evenly spaced time points
   rollout - the number of time steps past an input we will consider up to
   stencil - the stencil width for the solver matrix
   nx - the number of points in our spatial domain
Outputs:
   mse - the mse averaged over our different rollout periods
"""
def ml_loss(params, data, rollout, stencil): 
    # mse for each rollout period (1,2,...,rollout)
    mse = np.zeros(rollout)
    
    # Iterate over each time step
    # Make predictions through the rollout period (if enough time points)
   
    pred = ml_step(data[:,:stencil], rollout, params, stencil)
    # Get the L2 error
    mse += np.sum((pred[:,stencil:] - data[:,stencil:])**2, axis=0)
           
    # Get MSE
    mse /= np.arange(1,rollout+1)
    # print(np.round(mse[[0,50]],3))

    # Equally weight the losses across the different rollout periods
    mse = np.mean(mse)

    return mse


"""
Loss function to train the ML model
The L2 error of the model against the ground truth averaged across
the different rollout periods
Inputs:
   params - the parameters for the solver matrix which will be optimized
   data - the ground truth data at all evenly spaced time points
   rollout - the number of time steps past an input we will consider up to
   stencil - the stencil width for the solver matrix
   nx - the number of points in our spatial domain
Outputs:
   mse - the mse averaged over our different rollout periods
"""        
def train_ml(KS, dt, nx, rollout, stencil, f_rand, print_mes=True, nb=5):
    L = KS.l
    x = np.arange(0,L, L/nx)
    data_train = np.zeros((nb, rollout+stencil, len(x)))
    for i in range(nb):
        f = f_rand(KS.l)
        data_train[i,:,:] = KS_step(KS, rollout+stencil-1, f(x))    
    data_train = data_train.reshape(-1, data_train.shape[1])

    params0 = np.ones(stencil)/stencil
    result = minimize(ml_loss, params0, args=(data_train, rollout, stencil), method='CG')
    params = result.x

    if print_mes:
        print('Success! Learned params:', params)
        # print('Numerical a, b:', num_stencils(2, dt, dx)) 
    return params
    