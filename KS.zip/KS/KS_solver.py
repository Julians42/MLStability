import numpy as np

def KS_step(KS, num_steps, y0, all_steps=True):
    y_full = np.zeros((num_steps+1, len(y0)))
    y_full[0] = y0
    for i in range(num_steps):
        y_full[i+1] = KS.step(y_full[i])

    if all_steps:
        return y_full
    else:
        return y_full[-1]

# y0 must have shape (ncases, time). If there is only one case, then the
# code adds another 1st dimension
def ml_step(y0, num_steps, params, stencil, all_steps=True):
    if len(y0.shape)==1:
        y0 = np.expand_dims(y0, 0)
    stencil = len(params)
    assert(stencil == y0.shape[1])
    y_next = np.zeros((y0.shape[0], stencil+num_steps))
    y_next[:,:stencil] = y0
    for i in range(stencil-1, num_steps+stencil-1):
        y_next[:,i+1] = np.dot(y_next[:,i-stencil+1:i+1], params)
    
    if all_steps:
        return y_next
    else:
        return y_next[-1]
